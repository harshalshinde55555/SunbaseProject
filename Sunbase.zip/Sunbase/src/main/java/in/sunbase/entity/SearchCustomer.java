package in.sunbase.entity;
public class SearchCustomer {

	private String first_Name;
	private String city;
	private String email;
	private String phoneNo;
	public String getFirst_Name() {
		return first_Name;
	}
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "SearchCustomer [first_Name=" + first_Name + ", city=" + city + ", email=" + email + ", phoneNo="
				+ phoneNo + "]";
	}
	
}
